12WashereSpawnMenuFix 1.1.0 - optional local mod, no Workshop upload.

The recommended multiplayer installation is 12washere.pro-Patcher.exe, which
applies these assets directly and also fixes custom outfit preset loading.
You do not need to activate this local mod when using the patcher.

For local-mod use, copy mods/12WashereSpawnMenuFix into your Zomboid/mods
folder and enable it through the game Mods screen where appropriate.
Requires Louisville_Quarantine_Zone. This archive contains spawn-menu
metadata and EN/ID clothing labels only; it has no preset-reader patch.
It does not change server settings or download any Workshop items.
