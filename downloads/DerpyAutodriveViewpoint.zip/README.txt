Derpy Autodrive - Viewpoint Routes 0.5.3

Copy mods/DerpyAutodriveViewpoint into your own Zomboid/mods folder, then
restart Project Zomboid. For multiplayer, the server must also have the
same mod and enable DerpyAutodriveViewpoint in Mods=. Each player enables
the render add-on in Viewpoint settings: Delete > Add-ons.
Requires DerpyAutodrive, Viewpoint 0.1.7 / API 1.0.0, and ZombieBuddy.
Keep Panini projection off. General Settings select Navigation HUD, Road Guidance, Both or Off per
camera. Defaults: first-person HUD, third-person road guidance. Yellow
destination and green trajectory each have independent Line/Arrow controls.
The HUD offers 3D Direction Arrow with Car Heading by default; animated
Turn Arrow and Player POV remain selectable. 3D look-away fading defaults off. Configure under the
add-on settings. New driving-session verification is still pending.
The Windows patcher installs these same files automatically.
